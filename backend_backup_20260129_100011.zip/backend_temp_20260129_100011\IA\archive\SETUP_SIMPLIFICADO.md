# 🚀 DocHub IA - Setup Simplificado

## 📋 O que mudou?

Agora o sistema **tenta iniciar o backend automaticamente** quando você clicar em "Testar"!

## 🎯 Novo Fluxo (Super Simples)

### Opção 1: Automático (RECOMENDADO)

```
1. Clique duplo em: IA/iniciar_launcher.bat
   (deixe rodando em background)

2. Abra DocHub no navegador

3. ⚙️ → 🧪 Testar Conexão

4. Cole a API Key

5. Clique: 🚀 Testar Automaticamente

6. Sistema faz tudo sozinho:
   ✅ Verifica if backend está online
   ✅ Se não estiver, tenta iniciar
   ✅ Testa todos os modelos
   ✅ Mostra resultado
```

### Opção 2: Manual (Se preferir)

```
1. Clique duplo em: IA/iniciar_backend.bat

2. Clique duplo em: IA/iniciar_launcher.bat

3. Abra DocHub e teste
```

## 📁 Novos Arquivos

- **launcher.py** - Gerenciador que inicia o backend
- **iniciar_launcher.bat** - Script para iniciar o launcher

## ⚙️ Como Funciona

```
Seu Clique em "Testar"
        ↓
JavaScript verifica localhost:5000
        ↓
Se offline → Chama localhost:5001/start-backend
        ↓
Launcher executa backend.py
        ↓
Backend inicia em nova janela
        ↓
Sistema aguarda resposta
        ↓
Testa todos os modelos
        ↓
Mostra resultado
```

## 🚀 Passos Rápidos

1. **Primeira vez:**
   ```bash
   cd FRONTEND/IA
   instalar.bat
   ```

2. **Inicie o launcher:**
   ```bash
   iniciar_launcher.bat
   ```

3. **Abra DocHub e teste:**
   - Vá para ⚙️ → 🧪 Testar Conexão
   - Cole API Key
   - 🚀 Testar Automaticamente
   - Pronto! ✨

## 💡 Por que 2 servidores?

- **Launcher (5001)**: Gerencia e inicia o backend
- **Backend (5000)**: Processa requisições de API

O launcher fica sempre rodando, pronto para iniciar o backend quando necessário.

## 🛠️ Troubleshooting

### "Ainda não conecta"

Se mesmo assim não conectar:

1. Abra CMD na pasta IA
2. Execute manualmente:
   ```bash
   python backend.py
   ```
3. Em outro CMD/PowerShell:
   ```bash
   python launcher.py
   ```
4. Teste novamente no navegador

### "Launcher não responde"

Verifique se Flask está instalado:
```bash
pip install flask
```

---

**Muito mais simples agora!** 🎉
Clique em testar e tudo acontece automaticamente.
