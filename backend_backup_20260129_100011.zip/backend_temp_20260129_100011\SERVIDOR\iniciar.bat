@echo off
chcp 65001 > nul
setlocal enabledelayedexpansion
title DocHub Servidor
color 0B

:menu
cls
echo.
echo ╔═══════════════════════════════════════════════════════════╗
echo ║                   SERVIDOR DOCHUB IA                      ║
echo ║                                                           ║
echo ║              Gerenciador de Servidor Python              ║
echo ╚═══════════════════════════════════════════════════════════╝
echo.
echo   [1] Iniciar Servidor
echo   [2] Parar Servidor
echo   [3] Verificar Status
echo   [4] Reiniciar Servidor
echo   [5] Abrir em Background
echo   [0] Sair
echo.

set /p opcao="Escolha uma opcao: "

if "%opcao%"=="1" goto iniciar
if "%opcao%"=="2" goto parar
if "%opcao%"=="3" goto status
if "%opcao%"=="4" goto reiniciar
if "%opcao%"=="5" goto background
if "%opcao%"=="0" goto sair

echo.
echo [!] Opcao inválida!
timeout /t 2 > nul
goto menu

:iniciar
cls
echo.
echo ╔═══════════════════════════════════════════════════════════╗
echo ║   [>] Iniciando Servidor...                              ║
echo ╚═══════════════════════════════════════════════════════════╝
echo.

python server.py &
set pid=%errorlevel%

if %pid% EQU 0 (
    echo [OK] Servidor iniciado!
) else (
    echo [ERRO] Falha ao iniciar
)

timeout /t 3 > nul
goto menu

:parar
cls
echo.
echo ╔═══════════════════════════════════════════════════════════╗
echo ║   [X] Parando Servidor...                                ║
echo ╚═══════════════════════════════════════════════════════════╝
echo.

taskkill /f /im python.exe /fi "WINDOWTITLE eq Servidor*" >nul 2>&1

echo [OK] Servidor parado!
timeout /t 2 > nul
goto menu

:status
cls
echo.
echo ╔═══════════════════════════════════════════════════════════╗
echo ║   [?] Verificando Status...                              ║
echo ╚═══════════════════════════════════════════════════════════╝
echo.

python -c "import requests; r=requests.get('http://localhost:5001/status', timeout=1); print('[OK] ONLINE' if r.ok else '[X] OFFLINE')" 2>nul || echo [X] OFFLINE

timeout /t 3 > nul
goto menu

:reiniciar
cls
echo.
echo ╔═══════════════════════════════════════════════════════════╗
echo ║   [~] Reiniciando Servidor...                            ║
echo ╚═══════════════════════════════════════════════════════════╝
echo.

taskkill /f /im python.exe /fi "WINDOWTITLE eq Servidor*" >nul 2>&1
timeout /t 2 > nul

python server.py &
echo [OK] Servidor reiniciado!

timeout /t 3 > nul
goto menu

:background
cls
echo.
echo ╔═══════════════════════════════════════════════════════════╗
echo ║   [~] Iniciando em Background...                         ║
echo ╚═══════════════════════════════════════════════════════════╝
echo.

start /min "DocHub Server" python server.py
echo [OK] Servidor iniciado em background!

timeout /t 2 > nul
goto menu

:sair
cls
echo.
echo ╔═══════════════════════════════════════════════════════════╗
echo ║   Encerrando...                                           ║
echo ╚═══════════════════════════════════════════════════════════╝
echo.

taskkill /f /im python.exe /fi "WINDOWTITLE eq DocHub Server" >nul 2>&1

timeout /t 2 > nul
exit /b 0
