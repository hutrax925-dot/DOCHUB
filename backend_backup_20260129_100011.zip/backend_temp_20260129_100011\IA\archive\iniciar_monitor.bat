@echo off
REM Inicia o Monitor em background (invisível)
REM Ele monitora e auto-inicia o servidor

echo Iniciando Monitor...

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Erro: Python não encontrado
    pause
    exit /b 1
)

pip install requests -q

REM Cria VBScript para executar Python invisível
(
echo Set objShell = CreateObject("WScript.Shell"^)
echo objShell.Run "python monitor.py", 0, False
) > "%temp%\start_monitor.vbs"

REM Executa o VBScript
cscript.exe //nologo "%temp%\start_monitor.vbs"

REM Limpa
del "%temp%\start_monitor.vbs" >nul 2>&1

echo Monitor iniciado em background!
echo Você pode fechar esta janela.
echo.
echo Agora abra: index.html
echo.
pause
