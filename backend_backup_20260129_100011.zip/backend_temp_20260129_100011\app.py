#!/usr/bin/env python3
"""
DocHub IA - App Desktop com Webview
Integra o servidor, monitor e interface em um único executável
"""

import webview
import threading
import requests
import subprocess
import sys
import os
import time
import json

class API:
    """API para comunicação entre JS e Python"""
    
    def __init__(self):
        self.processo_servidor = None
    
    def iniciar_servidor(self):
        """Inicia o servidor ia.py"""
        # Verifica se já está rodando
        if self.servidor_online():
            return {'status': 'online', 'message': 'Servidor já está rodando'}
        
        try:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            ia_script = os.path.join(script_dir, 'IA', 'ia.py')
            
            print("[APP] Iniciando servidor...")
            
            if sys.platform == 'win32':
                # Windows - invisível
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE
                
                self.processo_servidor = subprocess.Popen(
                    [sys.executable, ia_script],
                    startupinfo=startupinfo,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
            else:
                # Linux/Mac
                self.processo_servidor = subprocess.Popen(
                    [sys.executable, ia_script],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    preexec_fn=os.setsid
                )
            
            print(f"[APP] Servidor iniciado (PID: {self.processo_servidor.pid})")
            
            # Aguarda ficar online
            for i in range(10):
                time.sleep(0.5)
                if self.servidor_online():
                    return {'status': 'started', 'message': 'Servidor iniciado com sucesso'}
            
            return {'status': 'timeout', 'message': 'Servidor iniciado mas demorou'}
        
        except Exception as e:
            print(f"[APP] Erro: {e}")
            return {'status': 'error', 'message': str(e)}
    
    def servidor_online(self):
        """Verifica se servidor está online"""
        try:
            response = requests.get('http://localhost:5000/health', timeout=2)
            return response.status_code == 200
        except:
            return False
    
    def parar_servidor(self):
        """Para o servidor"""
        if self.processo_servidor:
            try:
                self.processo_servidor.terminate()
                self.processo_servidor = None
            except:
                pass
        return {'status': 'stopped'}

def main():
    """Inicia o app"""
    # Instala dependências se necessário
    try:
        import requests
        import pywebview
    except ImportError:
        print("Instalando dependências...")
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pywebview', 'requests', '-q'])
    
    # Inicia o servidor
    api = API()
    
    # Carrega o HTML
    script_dir = os.path.dirname(os.path.abspath(__file__))
    html_path = os.path.join(script_dir, 'index.html')
    
    # Cria a janela do app
    window = webview.create_window(
        'DocHub IA',
        html_path,
        js_api=api,
        width=1200,
        height=800,
        resizable=True
    )
    
    print("[APP] Iniciando DocHub IA...")
    webview.start(window)
    
    # Para o servidor ao fechar o app
    api.parar_servidor()

if __name__ == '__main__':
    main()
