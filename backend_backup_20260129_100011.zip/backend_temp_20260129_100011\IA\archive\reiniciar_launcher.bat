@echo off
chcp 65001 >nul 2>&1
cd /d "%~dp0"






exit /b 0echo Reinicio completo.call "%~dp0iniciar_launcher.bat"call "%~dp0parar_launcher.bat"necho Reiniciando Launcher...