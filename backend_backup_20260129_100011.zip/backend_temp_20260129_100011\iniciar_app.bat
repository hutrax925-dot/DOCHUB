@echo off
REM DocHub IA - App Desktop

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Erro: Python não encontrado
    echo Instale em: https://www.python.org
    pause
    exit /b 1
)

echo Instalando dependências...
pip install pywebview requests -q

echo Iniciando DocHub IA...
python app.py

pause
