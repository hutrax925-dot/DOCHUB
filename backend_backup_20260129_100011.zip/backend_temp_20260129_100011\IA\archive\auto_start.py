#!/usr/bin/env python3
"""
Auto-Start Simples - Verifica e inicia o servidor
"""

import requests
import subprocess
import sys
import time
import os

def verificar_server():
    """Tenta acessar http://localhost:5000/health"""
    try:
        response = requests.get('http://localhost:5000/health', timeout=2)
        return response.status_code == 200
    except:
        return False

def iniciar_server():
    """Inicia ia.py"""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    ia_script = os.path.join(script_dir, 'ia.py')
    
    print("[AUTO-START] Servidor não respondeu. Iniciando ia.py...")
    
    # Executa ia.py em background
    if sys.platform == 'win32':
        # Windows - invisível
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = subprocess.SW_HIDE
        
        subprocess.Popen(
            [sys.executable, ia_script],
            startupinfo=startupinfo,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
    else:
        # Linux/Mac
        subprocess.Popen(
            [sys.executable, ia_script],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
    
    print("[AUTO-START] Aguardando servidor iniciar...")
    
    # Aguarda até 5 segundos
    for i in range(10):
        time.sleep(0.5)
        if verificar_server():
            print("[AUTO-START] ✅ Servidor online!")
            return True
    
    print("[AUTO-START] ⚠️ Timeout - servidor pode estar iniciando ainda")
    return True  # Mesmo assim retorna True, pode estar inicializando

def main():
    """Verifica e inicia o servidor se necessário"""
    print("[AUTO-START] Verificando servidor...")
    
    if verificar_server():
        print("[AUTO-START] ✅ Servidor já está online!")
        return True
    
    return iniciar_server()

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)
