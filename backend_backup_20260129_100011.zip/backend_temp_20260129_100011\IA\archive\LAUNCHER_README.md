# 🎮 Launcher IA - Gerenciador de Servidor

## 📋 O que é?

O Launcher é um **gerenciador de servidor** que permite iniciar/parar o servidor IA sem usar o terminal.

## 🚀 Como Usar?

### **Opção 1: Via Arquivo .bat (Recomendado)**

Clique duplo em:
```
IA/iniciar_launcher.bat
```

Ele abrirá uma janela e mostrará a URL para acessar.

### **Opção 2: Via Linha de Comando**

```powershell
cd "c:\Users\EdvanSilva-MACROGALP\Documents\TI\DOC\FRONTEND\IA"
python launcher.py
```

### **Opção 3: Via Navegador**

Abra seu navegador e acesse:
```
http://localhost:5001
```

## 📍 Hierarquia de Servidores

```
🎮 Launcher (Porta 5001)
    ├─ Interface Web
    ├─ GET  /status  → Verifica status
    ├─ POST /start   → Inicia servidor
    └─ POST /stop    → Para servidor
        ↓
    🔌 Servidor IA (Porta 5000)
        ├─ GET  /health   → Health check
        ├─ POST /validate → Valida API Key
        └─ POST /chat     → Envia mensagem
```

## ✨ Recursos

✅ **Interface Visual** - Não precisa de terminal para controlar
✅ **Status em Tempo Real** - Atualiza a cada 2 segundos
✅ **Background** - Servidor roda invisível em segundo plano
✅ **Fácil de Usar** - Apenas 3 botões: Iniciar, Parar, Atualizar

## 🎯 Fluxo de Uso

1. **Iniciar Launcher**: Clique duplo em `iniciar_launcher.bat`
2. **Abrir Navegador**: Acesse `http://localhost:5001`
3. **Iniciar Servidor**: Clique no botão 🟢 **Iniciar**
4. **Fechar Janela**: O servidor continua rodando!
5. **Usar o Site**: Abra `http://localhost/index.html` e use normalmente
6. **Parar Servidor**: Volte ao Launcher e clique em 🔴 **Parar**

## 📊 Status do Servidor

A interface mostra 3 estados:

- **✅ Servidor Rodando** - Pronto para receber requisições
- **⛔ Servidor Desligado** - Clique em Iniciar para começar
- **❌ Erro na Conexão** - Problema ao conectar com o Launcher

## 🛑 Desligar o Servidor

Duas opções:

### **Opção 1: Via Launcher (Recomendado)**
1. Abra `http://localhost:5001`
2. Clique em 🔴 **Parar**
3. Confirme a ação

### **Opção 2: Fechar Tudo**
Pressione **Ctrl+C** na janela do Launcher

## 📝 Logs

Todos os eventos aparecem na janela do Launcher:

```
[12:57:31] GET /status → 200 OK
[12:57:32] POST /start → INICIANDO...
✅ Servidor iniciado (PID: 12345)
[12:57:35] GET /status → 200 OK
```

## 🔗 URLs Importantes

- **Launcher**: `http://localhost:5001`
- **Servidor**: `http://localhost:5000`
- **Site**: `http://localhost/index.html`

## ⚙️ Requisitos

- Python 3.7+
- Módulos: `psutil` (instalado automaticamente)

## 🆘 Troubleshooting

**P: Não consegue conectar ao Launcher?**
> Verifique se a porta 5001 não está bloqueada

**P: Servidor não inicia?**
> Veja os logs na janela do Launcher para detalhes

**P: Preciso fechar o Launcher para desligar o servidor?**
> NÃO! Use o botão 🔴 Parar na interface

---

**Desenvolvido para DocHub IA** 🤖
