@echo off
chcp 65001 >nul 2>&1

title Launcher IA - DocHub

cls
echo.
echo ============================================================
echo    🎮 LAUNCHER IA - Gerenciador de Servidor
echo ============================================================
echo.
echo    ✅ Iniciando em background...
echo.
echo ============================================================

REM Iniciar Python em background a partir da raiz do frontend e logar em launcher.log
REM Mudamos o diretório para a pasta pai (raiz do frontend) antes de iniciar
start "" /B cmd /c "cd /d \"%~dp0..\" && python \"%~dp0launcher_novo.py\" > \"%~dp0launcher.log\" 2>&1"

timeout /t 1 /nobreak >nul

REM Aguarda até 6s pela criação do launcher.pid
set FOUND=0
for /l %%i in (1,1,6) do (
    if exist "%~dp0launcher.pid" (
        set FOUND=1
        goto :FOUND_PID
    )
    timeout /t 1 /nobreak >nul
)
:FOUND_PID
if "%FOUND%"=="1" (
    set /p PID=<"%~dp0launcher.pid"
    echo Launcher iniciado (PID %PID%). Aguardando resposta...
    REM Testa endpoint de status (pode demorar um pouco)
    powershell -Command "try { $r = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:5001/status' -TimeoutSec 5 -ErrorAction Stop; $r.Content | ConvertFrom-Json | ConvertTo-Json } catch { Write-Error 'Sem resposta' }"
    start http://127.0.0.1:5001
) else (
    echo ERRO: PID nao encontrado apos aguardar. Verifique launcher.log
    powershell -Command "Get-Content -Path '%~dp0launcher.log' -Tail 200 | Out-String"
)

echo.
echo ============================================================
echo    Para parar o launcher execute: parar_launcher.bat
echo ============================================================

exit /b 0
