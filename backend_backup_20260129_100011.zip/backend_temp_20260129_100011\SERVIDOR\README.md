mano, deleta ma# 🚀 SERVIDOR - Gerenciador de IA

## 📍 Você Está Aqui

```
FRONTEND/
├── SERVIDOR/
│   ├── INICIAR_SERVIDOR.bat    ← CLIQUE AQUI PARA INICIAR
│   ├── launcher.py
│   ├── README.md                ← Você está lendo isso
│   └── ...
├── index.html
├── script.js
└── ...
```

---

## ⚡ Como Usar

### 1️⃣ Iniciar o Servidor

**Duplo-clique em:**
```
INICIAR_SERVIDOR.bat
```

Uma janela CMD vai abrir mostrando:
```
========================================================
  🚀 DocHub - Gerenciador de Servidor IA
========================================================

[LAUNCHER] Escutando em http://localhost:5001
[LAUNCHER] Aguardando requisições do frontend...
```

✅ Deixe essa janela **ABERTA** (minimize se quiser)

---

### 2️⃣ Usar o Frontend

Abra seu navegador e acesse:
```
http://localhost:8000  (ou a porta do seu app)
```

Vá em: **⚙️ Configurações → 🔑 API & Modelo**

Procure pela seção: **🚀 Servidor Backend**

Clique em: **▶️ Iniciar Servidor**

✅ Pronto! O servidor ia.py vai iniciar automaticamente

---

### 3️⃣ Controlar o Servidor (pelo Frontend)

Na mesma seção "🚀 Servidor Backend":

| Botão | O que faz |
|-------|-----------|
| **▶️ Iniciar Servidor** | Liga ia.py |
| **⏹️ Parar Servidor** | Desliga ia.py |
| **🔍 Verificar Status** | Mostra se está online |

---

## 📊 O que Acontece

```
1. Você duplo-clica em: INICIAR_SERVIDOR.bat
                    ↓
2. Launcher abre em: http://localhost:5001
                    ↓
3. Você clica em "▶️ Iniciar" no frontend
                    ↓
4. Launcher executa: python ../IA/ia.py
                    ↓
5. ia.py abre em: http://localhost:5000
                    ↓
6. Chat IA funciona! ✅
```

---

## 🧪 Verificar se Está Funcionando

### Opção 1: Ver Status no Frontend
1. Abra as Configurações de IA
2. Procure por "Servidor Backend"
3. Veja o status: ✅ Online ou ❌ Offline

### Opção 2: Verificar pela Janela do CMD
A janela do Launcher mostra mensagens tipo:
```
[LAUNCHER] ✅ ia.py iniciado (PID: 12345)
[LAUNCHER] ✅ ia.py respondendo em http://localhost:5000!
```

---

## 🆘 Troubleshooting

### "Porta 5001 já está em uso"
```
❌ Outro programa está usando essa porta
✅ Feche a janela do Launcher anterior
✅ Ou reinicie o computador
```

### "Erro ao iniciar ia.py"
```
❌ Pode estar faltando dependência em ../IA/requirements.txt
✅ Abra terminal: pip install -r ../IA/requirements.txt
```

### "Servidor não responde"
```
❌ Verifique se ia.py está rodando
✅ Clique em "🔍 Verificar Status" no frontend
✅ Se offline, clique em "▶️ Iniciar Servidor"
```

---

## 📁 Arquivos nesta Pasta

| Arquivo | O que faz |
|---------|-----------|
| `INICIAR_SERVIDOR.bat` | Duplo-clique para abrir o gerenciador |
| `launcher.py` | Python que controla ia.py |
| `README.md` | Este arquivo (instruções) |

---

## 📚 Documentos Úteis

Volte para a pasta FRONTEND para ver:
- `RAPIDO.md` - Referência rápida
- `COMO_USAR_SERVIDOR_AUTOMATICO.md` - Guia completo
- `ONDE_CLICAR.md` - Onde clicar no frontend

---

## ✅ Resumo

1. **CLIQUE AQUI**: `INICIAR_SERVIDOR.bat`
2. **DEIXE ABERTO**: A janela do CMD
3. **USE NORMALMENTE**: O frontend + clique em "Iniciar Servidor"
4. **PRONTO**: Chat IA funciona! 🎉

---

**É isso! Simples, direto e funcional! 🚀**
