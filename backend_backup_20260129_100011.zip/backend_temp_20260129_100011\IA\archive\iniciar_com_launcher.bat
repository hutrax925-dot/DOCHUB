@echo off
REM Inicia o Launcher de forma invisível (sem janela CMD visível)
REM O Launcher monitora e inicia ia.py automaticamente em background

cls
echo.
echo ===============================================
echo   DocHub IA - Auto-Start Silencioso
echo ===============================================
echo.
echo 🚀 Iniciando launcher em background...
echo    (Nenhuma janela extra será aberta)
echo.

REM Verifica se Python está instalado
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python não encontrado!
    echo.
    echo Instale Python em: https://www.python.org
    pause
    exit /b 1
)

echo ✅ Python encontrado

REM Instala requests se necessário
echo 📦 Instalando dependências...
pip install requests -q

REM Inicia o Launcher em background (invisível) usando VBScript
echo ✅ Iniciando launcher...

REM Cria um VBScript temporário para executar Python de forma invisível
(
echo Set objShell = CreateObject("WScript.Shell"^)
echo objShell.Run "cmd /c cd /d \"%~dp0..\" && python \"%~dp0launcher_novo.py\"", 0, False
) > "%temp%\run_launcher.vbs"

REM Executa o VBScript (que executa Python de forma invisível)
cscript.exe //nologo "%temp%\run_launcher.vbs" >nul 2>&1

REM Limpa o arquivo temporário
del "%temp%\run_launcher.vbs" >nul 2>&1

echo.
echo ✨ Sistema pronto!
echo.
echo 📝 Próximos passos:
echo    1. Abra: index.html no navegador
echo    2. Clique em: ⚙️ → 🧪 Testar Conexão
echo    3. Cole sua API Key
echo    4. Clique em: 🚀 Testar Automaticamente
echo    5. O servidor será iniciado automaticamente se necessário!
echo.
echo 💡 Esta janela pode ser fechada - o launcher continua rodando!
echo.

pause

