@echo off
REM Inicia o DocHub IA - Auto-Start Simples

echo.
echo =========================================
echo   DocHub IA - Auto-Start
echo =========================================
echo.

REM Verifica Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Python não encontrado!
    pause
    exit /b 1
)

echo ✅ Python ok
echo.

REM Instala requests se necessário
echo 📦 Instalando dependências...
pip install requests -q >nul 2>&1

echo ✅ Pronto!
echo.

REM Executa auto_start.py (verifica e inicia o servidor)
echo 🚀 Verificando servidor...
python auto_start.py

echo.
echo ✨ Abra: index.html no navegador
echo.

pause
