# 🚀 DocHub - Chat IA Avançado

## ⚙️ Configuração de IA

### 1. Instalar Dependências Python

```bash
pip install -r requirements.txt
```

### 2. Iniciar Backend Python

```bash
python ai_backend.py
```

O servidor rodará em `http://localhost:5000`

### 3. Configurar API Key OpenAI

1. Acesse: [https://platform.openai.com/api-keys](https://platform.openai.com/api-keys)
2. Crie uma nova chave de API
3. Cole em **Configurações → API & Modelo**
4. Clique em **🔍 Validar Chave**

## 📋 Funcionalidades

### ✅ Validação de API Key
- Verifica se a chave é válida em tempo real
- Mostra status verde (✅) ou vermelho (❌)

### 🤖 Modelos Suportados
- **GPT 3.5 Turbo** - Rápido e econômico
- **GPT 4** - Mais poderoso
- **GPT 4 Turbo** - Equilíbrio perfeito

### ⚡ Controle de Temperatura
- **0.0**: Respostas determinísticas (sempre iguais)
- **0.5**: Equilíbrio
- **0.7**: Criatividade moderada (recomendado)
- **1.0**: Muito criativo (pode ser inconsistente)

### 📋 System Prompt
Define como a IA se comporta. Exemplo:
```
Você é um especialista em desenvolvimento web.
Responda em português brasileiro.
Seja conciso e técnico.
```

### 💬 Chat Funcional
- Envia mensagens direto para OpenAI
- Suporta context da documentação
- Histórico completo do chat
- Limpar chat com 🗑️

## 🔧 Troubleshooting

### Erro: "Erro de conexão ao backend"
- Verifique se `python ai_backend.py` está rodando
- Teste: `curl http://localhost:5000/health`

### Erro: "API Key inválida"
- Verifique em [https://platform.openai.com/account/billing/limits](https://platform.openai.com/account/billing/limits)
- Certifique-se que a chave começa com `sk-`
- Verifique se tem saldo na conta OpenAI

### Chat não responde
- Confirme que API Key foi validada (badge verde)
- Verifique limite de requisições na conta OpenAI
- Aumentar timeout se modelar usar GPT-4

## 📱 Estrutura de Arquivos

```
FRONTEND/
├── index.html              # Interface principal
├── script.js               # Lógica frontend + chat
├── styles.css              # Estilos
├── ai_backend.py           # Servidor Python (core IA)
├── requirements.txt        # Dependências Python
└── README.md              # Este arquivo
```

## 🔐 Segurança

- API Key salva apenas localmente (localStorage)
- Backend valida requisições
- CORS configurado apenas para localhost
- Nunca envie API Key em URLs

## 📝 Notas

- Cada mensagem consome tokens OpenAI (verifique custos)
- Max tokens padrão: 2000 (ajuste conforme necessário)
- System Prompt afeta todas as respostas
- Temperatura afeta criatividade (não qualidade)

---

**Desenvolvido com ❤️ para documentação inteligente**
