#!/usr/bin/env python3
"""
Launcher - Gerenciador do Servidor IA
Roda em http://localhost:5001
Permite iniciar/parar o servidor IA em background
"""

import signal
import atexit
from http.server import HTTPServer, BaseHTTPRequestHandler, socketserver
import json
import subprocess
import os
from datetime import datetime
import psutil
import sys
import threading
import time

# Ensure stdout uses UTF-8 when possible to avoid encoding errors when redirected to a file
try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass


class LauncherHandler(BaseHTTPRequestHandler):
    """Handler para requisições do Launcher"""

    def log_event(self, method, path, status=None):
        """Log detalhado (nome diferente para não colidir com BaseHTTPRequestHandler.log_request)"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        status_str = f" -> {status}" if status else ""
        sys.stdout.write(f"[{timestamp}] {method} {path}{status_str}\n")
        sys.stdout.flush()

    def do_GET(self):
        """GET - Páginas e status"""
        try:
            if self.path == '/status':
                self.log_event('GET', self.path, '200')
                servidor_rodando = self.verificar_servidor()
                self.send_response(200)
                self.send_header(
                    'Content-type', 'application/json; charset=utf-8')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Connection', 'close')
                self.end_headers()

                resposta = {
                    'status': 'running' if servidor_rodando else 'stopped',
                    'launcher_port': 5001,
                    'server_port': 5000,
                    'timestamp': datetime.now().isoformat()
                }
                self.wfile.write(json.dumps(resposta).encode('utf-8'))

            elif self.path == '/':
                self.log_event('GET', '/', '200')
                self.enviar_html()
            elif self.path == '/ping':
                # health check quick endpoint
                self.log_event('GET', '/ping', '200')
                self.send_response(200)
                self.send_header('Content-type', 'text/plain')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Connection', 'close')
                self.end_headers()
                try:
                    self.wfile.write(b'pong')
                    self.wfile.flush()
                except Exception:
                    pass
            else:
                self.send_response(404)
                self.send_header('Content-type', 'text/plain')
                self.end_headers()
                self.wfile.write(b'404 Not Found')

        except Exception as e:
            sys.stdout.write(f"[ERRO GET] {str(e)}\n")
            sys.stdout.flush()
            try:
                self.send_error(500, str(e))
            except:
                pass

    def do_POST(self):
        """POST - Controlar servidor"""
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            if content_length > 0:
                self.rfile.read(content_length)

            if self.path == '/start':
                self.log_event('POST', '/start', 'PROCESSANDO')
                self.iniciar_servidor()
            elif self.path == '/stop':
                self.log_event('POST', '/stop', 'PROCESSANDO')
                self.parar_servidor()
            elif self.path == '/shutdown':
                # Para o próprio launcher (parada limpa)
                self.log_event('POST', '/shutdown', 'PARANDO_LAUNCHER')
                self.enviar_json(
                    200, {'success': True, 'message': 'Launcher will shut down'})
                # Realiza shutdown em background para permitir que a resposta seja enviada

                def shutdown_server():
                    try:
                        # small delay to ensure the HTTP response is flushed before shutting down
                        time.sleep(0.25)
                        # Remove pid file
                        pid_file = os.path.join(
                            os.path.dirname(__file__), 'launcher.pid')
                        try:
                            if os.path.exists(pid_file):
                                os.remove(pid_file)
                                sys.stdout.write(
                                    f"PID file removed by shutdown: {pid_file}\n")
                                sys.stdout.flush()
                        except Exception as e:
                            sys.stdout.write(
                                f"Erro removendo pid no shutdown: {e}\n")
                            sys.stdout.flush()
                        # Shutdown the HTTP server
                        try:
                            self.server.shutdown()
                        except Exception as e:
                            sys.stdout.write(f"Erro ao chamar shutdown: {e}\n")
                            sys.stdout.flush()
                    except Exception as ee:
                        sys.stdout.write(f"Erro no shutdown_server: {ee}\n")
                        sys.stdout.flush()
                t = threading.Thread(target=shutdown_server, daemon=True)
                t.start()
            else:
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b'Endpoint not found')

        except Exception as e:
            sys.stdout.write(f"[ERRO POST] {str(e)}\n")
            sys.stdout.flush()
            try:
                self.send_error(500, str(e))
            except:
                pass

    def do_OPTIONS(self):
        """Handle CORS preflight"""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Connection', 'close')
        self.end_headers()

    def verificar_servidor(self):
        """Verifica se servidor IA está rodando"""
        try:
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    cmdline = proc.info.get('cmdline') or []
                    if isinstance(cmdline, list) and any('ia.py' in str(arg) for arg in cmdline):
                        return True
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            return False
        except Exception as e:
            sys.stdout.write(f"[WARN] Erro ao verificar servidor: {e}\n")
            sys.stdout.flush()
            return False

    def iniciar_servidor(self):
        """Inicia o servidor IA em background"""
        try:
            if self.verificar_servidor():
                self.enviar_json(200, {
                    'success': False,
                    'error': 'Servidor já está rodando!'
                })
                return

            # Determina paths: preferir o wrapper em SERVIDOR/server.py (se existir) e usar a raiz do frontend como cwd
            frontend_root = os.path.abspath(
                os.path.join(os.path.dirname(__file__), '..'))
            server_wrapper = os.path.join(
                frontend_root, 'SERVIDOR', 'server.py')
            ia_path = os.path.join(os.path.dirname(__file__), 'ia.py')

            # Escolhe qual script iniciar
            if os.path.exists(server_wrapper):
                target = server_wrapper
            elif os.path.exists(ia_path):
                target = ia_path
            else:
                self.enviar_json(200, {
                    'success': False,
                    'error': f'Arquivo de servidor não encontrado: {server_wrapper} ou {ia_path}'
                })
                return

            # Iniciar em thread para não bloquear
            def run_subprocess():
                try:
                    if os.name == 'nt':
                        subprocess.Popen(
                            [sys.executable, target],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL,
                            creationflags=subprocess.CREATE_NO_WINDOW,
                            cwd=frontend_root
                        )
                    else:
                        subprocess.Popen(
                            [sys.executable, target],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL,
                            start_new_session=True,
                            cwd=frontend_root
                        )
                    sys.stdout.write(
                        f"Servidor iniciado (executando: {os.path.basename(target)})\n")
                    sys.stdout.flush()
                except Exception as e:
                    sys.stdout.write(f"❌ Erro ao iniciar: {e}\n")
                    sys.stdout.flush()

            thread = threading.Thread(target=run_subprocess, daemon=True)
            thread.start()

            self.enviar_json(200, {
                'success': True,
                'message': 'Servidor está sendo iniciado...'
            })

        except Exception as e:
            sys.stdout.write(f"❌ Erro: {str(e)}\n")
            sys.stdout.flush()
            self.enviar_json(200, {
                'success': False,
                'error': str(e)
            })

    def parar_servidor(self):
        """Para o servidor IA"""
        try:
            parou = False

            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    cmdline = proc.info.get('cmdline') or []
                    if isinstance(cmdline, list) and any('ia.py' in str(arg) for arg in cmdline):
                        proc.terminate()
                        try:
                            proc.wait(timeout=3)
                        except psutil.TimeoutExpired:
                            proc.kill()
                        parou = True
                        sys.stdout.write(
                            f"✅ Processo terminado: {proc.info['pid']}\n")
                        sys.stdout.flush()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass

            if parou:
                self.enviar_json(200, {
                    'success': True,
                    'message': 'Servidor desligado com sucesso'
                })
            else:
                self.enviar_json(200, {
                    'success': False,
                    'error': 'Nenhum servidor em execução'
                })

        except Exception as e:
            sys.stdout.write(f"❌ Erro ao parar: {str(e)}\n")
            sys.stdout.flush()
            self.enviar_json(200, {
                'success': False,
                'error': str(e)
            })

    def enviar_json(self, status_code, dados):
        """Envia resposta JSON"""
        try:
            self.send_response(status_code)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Connection', 'close')
            try:
                self.end_headers()
            except Exception:
                pass

            try:
                json_bytes = json.dumps(
                    dados, ensure_ascii=False).encode('utf-8')
                self.wfile.write(json_bytes)
                try:
                    self.wfile.flush()
                except Exception:
                    pass
            except Exception as e:
                sys.stdout.write(f"[ERRO] Erro ao escrever resposta: {e}\n")
                sys.stdout.flush()
        except Exception as e:
            # Log and silently ignore to avoid crashing the handler
            sys.stdout.write(f"[ERRO] Erro ao enviar JSON: {e}\n")
            sys.stdout.flush()

    def enviar_html(self):
        """Envia interface HTML"""
        html = """<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Launcher IA - DocHub</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            padding: 40px;
            max-width: 500px;
            width: 100%;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 10px;
            font-size: 28px;
        }
        .subtitle {
            text-align: center;
            color: #999;
            margin-bottom: 30px;
            font-size: 14px;
        }
        .status-box {
            background: #f5f5f5;
            padding: 30px;
            border-radius: 8px;
            margin-bottom: 25px;
            text-align: center;
            border-left: 5px solid #667eea;
        }
        .status-icon {
            font-size: 64px;
            margin-bottom: 15px;
        }
        .status-text {
            font-size: 20px;
            color: #333;
            margin-bottom: 10px;
            font-weight: 600;
        }
        .status-info {
            font-size: 12px;
            color: #999;
        }
        .buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 20px;
        }
        button {
            padding: 12px 20px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s;
            font-weight: 600;
            color: white;
        }
        .btn-start {
            background: #28a745;
            grid-column: 1;
        }
        .btn-start:hover:not(:disabled) {
            background: #218838;
            transform: translateY(-2px);
        }
        .btn-stop {
            background: #dc3545;
            grid-column: 2;
        }
        .btn-stop:hover:not(:disabled) {
            background: #c82333;
            transform: translateY(-2px);
        }
        .btn-refresh {
            background: #007bff;
            grid-column: 1 / -1;
        }
        .btn-refresh:hover:not(:disabled) {
            background: #0056b3;
            transform: translateY(-2px);
        }
        button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        .message {
            padding: 12px;
            border-radius: 6px;
            margin-top: 20px;
            text-align: center;
            animation: slideIn 0.3s ease-out;
        }
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .message.info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .footer {
            text-align: center;
            font-size: 11px;
            color: #999;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎮 Launcher IA</h1>
        <p class="subtitle">Gerenciador de Servidor</p>
        
        <div class="status-box">
            <div class="status-icon" id="statusIcon">⏳</div>
            <div class="status-text" id="statusText">Carregando...</div>
            <div class="status-info" id="statusInfo"></div>
        </div>
        
        <div class="buttons">
            <button class="btn-start" id="startBtn" onclick="iniciar()">🟢 Iniciar</button>
            <button class="btn-stop" id="stopBtn" onclick="parar()">🔴 Parar</button>
            <button class="btn-refresh" id="refreshBtn" onclick="atualizar()">🔄 Atualizar</button>
        </div>
        
        <div id="message"></div>
        
        <div class="footer">
            Porta 5001 | Servidor IA na porta 5000
        </div>
    </div>

    <script>
        let atualizando = false;

        async function atualizar() {
            if (atualizando) return;
            atualizando = true;
            
            try {
                const resp = await fetch('/status');
                const dados = await resp.json();
                
                const icon = dados.status === 'running' ? '🟢' : '🔴';
                const texto = dados.status === 'running' ? 'Servidor Rodando' : 'Servidor Parado';
                const hora = new Date(dados.timestamp).toLocaleTimeString('pt-BR');
                
                document.getElementById('statusIcon').textContent = icon;
                document.getElementById('statusText').textContent = texto;
                document.getElementById('statusInfo').textContent = 'Porta 5000 | ' + hora;
                
                document.getElementById('startBtn').disabled = dados.status === 'running';
                document.getElementById('stopBtn').disabled = dados.status === 'stopped';
                
            } catch (err) {
                document.getElementById('statusIcon').textContent = '❌';
                document.getElementById('statusText').textContent = 'Erro de Conexão';
                document.getElementById('statusInfo').textContent = err.message;
                document.getElementById('startBtn').disabled = true;
                document.getElementById('stopBtn').disabled = true;
            } finally {
                atualizando = false;
            }
        }

        async function iniciar() {
            document.getElementById('startBtn').disabled = true;
            const msg = document.getElementById('message');
            
            try {
                const resp = await fetch('/start', { method: 'POST' });
                const dados = await resp.json();
                
                if (dados.success) {
                    msg.textContent = '✅ Servidor iniciado! Aguardando...';
                    msg.className = 'message success';
                    setTimeout(() => atualizar(), 2000);
                } else {
                    msg.textContent = '❌ Erro: ' + dados.error;
                    msg.className = 'message error';
                    document.getElementById('startBtn').disabled = false;
                }
            } catch (err) {
                msg.textContent = '❌ Erro: ' + err.message;
                msg.className = 'message error';
                document.getElementById('startBtn').disabled = false;
            }
        }

        async function parar() {
            document.getElementById('stopBtn').disabled = true;
            const msg = document.getElementById('message');
            
            try {
                const resp = await fetch('/stop', { method: 'POST' });
                const dados = await resp.json();
                
                if (dados.success) {
                    msg.textContent = '✅ Servidor desligado com sucesso!';
                    msg.className = 'message success';
                    setTimeout(() => atualizar(), 1000);
                } else {
                    msg.textContent = '❌ Erro: ' + dados.error;
                    msg.className = 'message error';
                    document.getElementById('stopBtn').disabled = false;
                }
            } catch (err) {
                msg.textContent = '❌ Erro: ' + err.message;
                msg.className = 'message error';
                document.getElementById('stopBtn').disabled = false;
            }
        }

        // Inicializar
        atualizar();
        setInterval(atualizar, 3000);
    </script>
</body>
</html>"""

        try:
            self.send_response(200)
            self.send_header('Content-type', 'text/html; charset=utf-8')
            self.send_header('Connection', 'close')
            self.end_headers()
            self.wfile.write(html.encode('utf-8'))
        except Exception as e:
            sys.stdout.write(f"[ERRO] Erro ao enviar HTML: {e}\n")
            sys.stdout.flush()

    def log_message(self, format, *args):
        """Silencia logs padrão do HTTPServer"""
        pass


class ThreadedHTTPServer(socketserver.ThreadingMixIn, HTTPServer):
    """Servidor HTTP com suporte a threading"""
    daemon_threads = True


def remove_pid(pid_file_path):
    try:
        if os.path.exists(pid_file_path):
            os.remove(pid_file_path)
            sys.stdout.write(f"PID file removido: {pid_file_path}\n")
            sys.stdout.flush()
    except Exception as e:
        sys.stdout.write(f"Erro removendo pid: {e}\n")
        sys.stdout.flush()


def main():
    """Função principal"""
    port = 5001
    server_address = ('localhost', port)
    pid_file = os.path.join(os.path.dirname(__file__), 'launcher.pid')

    try:
        # escreve pid
        with open(pid_file, 'w') as f:
            f.write(str(os.getpid()))
        atexit.register(remove_pid, pid_file)

        # handlers de sinais para garantir limpeza
        def handle_exit(signum, frame):
            sys.stdout.write(f"Recebido sinal {signum}, encerrando...\n")
            sys.stdout.flush()
            try:
                httpd.shutdown()
            except:
                pass
            remove_pid(pid_file)
            sys.exit(0)

        for s in (signal.SIGINT, signal.SIGTERM):
            try:
                signal.signal(s, handle_exit)
            except Exception:
                pass

        httpd = ThreadedHTTPServer(server_address, LauncherHandler)

        print("\n" + "="*60)
        print("   LAUNCHER IA")
        print("="*60)
        print(f"   URL: http://localhost:{port}")
        print(f"   Inicio: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
        print("="*60)
        print("   Endpoints:")
        print("   - GET  /      -> Interface Web")
        print("   - GET  /status -> Status JSON")
        print("   - POST /start  -> Iniciar servidor IA")
        print("   - POST /stop   -> Parar servidor IA")
        print("="*60)
        print("   Pressione Ctrl+C para parar\n")
        sys.stdout.flush()

        try:
            httpd.serve_forever()
        finally:
            # limpeza
            remove_pid(pid_file)

    except KeyboardInterrupt:
        print("\n" + "="*60)
        print("   ⛔ LAUNCHER PARADO")
        print("="*60)
        print(f"   Fim: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
        print("="*60 + "\n")
        sys.stdout.flush()
        try:
            httpd.shutdown()
        except:
            pass
    except Exception as e:
        print(f"\n[ERRO FATAL] {e}\n")
        sys.stdout.flush()
        remove_pid(pid_file)
        sys.exit(1)


if __name__ == '__main__':
    main()
