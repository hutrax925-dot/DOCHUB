@echo off
chcp 65001 >nul 2>&1
cd /d "%~dp0"

if not exist "%~dp0launcher.pid" (
    echo Nenhum launcher encontrado (arquivo launcher.pid ausente).
    exit /b 1
)
set /p PID=<"%~dp0launcher.pid"
echo Parando launcher (PID %PID%)...
rem Tenta pedir ao launcher via endpoint para encerrar o servidor IA (parada limpa)
powershell -Command "try { Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:5001/stop' -Method POST -TimeoutSec 5 -ErrorAction Stop } catch { Write-Error 'Sem resposta' }"

rem Em seguida solicita o shutdown do próprio launcher
powershell -Command "try { Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:5001/shutdown' -Method POST -TimeoutSec 5 -ErrorAction Stop } catch { Write-Error 'Sem resposta' }"

rem Aguarda até 10s verificação da remoção do arquivo PID
for /l %%i in (1,1,10) do (
    if not exist "%~dp0launcher.pid" (
        echo Launcher parado com sucesso.
        exit /b 0
    )
    timeout /t 1 /nobreak >nul
)

nrem Se chegou aqui, ainda pode haver processo vivo; força kill
tasklist /fi "PID eq %PID%" | findstr /I "%PID%" >nul
if errorlevel 1 (
    echo Processo nao existe mais.
    if exist "%~dp0launcher.pid" del "%~dp0launcher.pid"
    exit /b 0
) else (
    echo Forcando finalizacao do processo...
    taskkill /PID %PID% /T /F >nul 2>&1
    timeout /t 1 /nobreak >nul
    echo Feito.
    if exist "%~dp0launcher.pid" del "%~dp0launcher.pid"
    
    rem Verifica se a porta 5001 foi liberada
    for /l %%j in (1,1,5) do (
        netstat -ano | findstr "5001" >nul
        if errorlevel 1 (
            echo Porta 5001 liberada. Launcher encerrado com sucesso.
            exit /b 0
        )
        timeout /t 1 /nobreak >nul
    )
    echo Aviso: Porta 5001 ainda esta em uso. Verifique manualmente.
    exit /b 0
)

















