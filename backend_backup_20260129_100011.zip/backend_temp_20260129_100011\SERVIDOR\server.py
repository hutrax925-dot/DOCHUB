#!/usr/bin/env python3
"""
DocHub Servidor Simples
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import subprocess
import sys
import os
import time

try:
    import requests
except:
    requests = None


class Servidor:
    def __init__(self):
        self.processo = None
        self.parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    def get_ia_path(self):
        return os.path.join(self.parent_dir, 'IA', 'ia.py')
    
    def is_online(self):
        if not requests:
            return False
        try:
            r = requests.get('http://localhost:5000/health', timeout=1)
            return r.status_code == 200
        except:
            return False
    
    def start(self):
        if self.is_online():
            return False
        
        path = self.get_ia_path()
        if not os.path.exists(path):
            return False
        
        try:
            self.processo = subprocess.Popen(
                [sys.executable, path],
                cwd=self.parent_dir,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            
            for _ in range(20):
                time.sleep(0.5)
                if self.is_online():
                    return True
            
            return False
        except:
            return False
    
    def stop(self):
        if self.processo:
            try:
                self.processo.terminate()
                self.processo.wait(timeout=2)
            except:
                try:
                    self.processo.kill()
                except:
                    pass
        self.processo = None
        return True
    
    def status(self):
        return self.is_online()


srv = Servidor()


class Handler(BaseHTTPRequestHandler):
    
    def do_GET(self):
        if self.path == '/status':
            online = srv.status()
            response = json.dumps({'status': 'online' if online else 'offline'}).encode()
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(response)
        else:
            self.send_error(404)
    
    def do_POST(self):
        if self.path == '/start':
            ok = srv.start()
            response = json.dumps({'success': ok}).encode()
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(response)
        elif self.path == '/stop':
            ok = srv.stop()
            response = json.dumps({'success': ok}).encode()
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(response)
        else:
            self.send_error(404)
    
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.end_headers()
    
    def log_message(self, format, *args):
        return


if __name__ == '__main__':
    httpd = HTTPServer(('localhost', 5001), Handler)
    print('Servidor rodando na porta 5001...')
    httpd.serve_forever()
