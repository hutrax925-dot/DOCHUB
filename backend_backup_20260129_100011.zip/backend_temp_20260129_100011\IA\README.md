# 🤖 DocHub IA - Servidor Python Simplificado

Sistema de IA integrado ao DocHub com validação de API Keys e chat funcional.

## 📋 Estrutura

```
IA/
├── ia.py               # 🎯 Servidor Python com OpenAI (core)
├── iniciar.bat         # 🎯 Script para iniciar (Windows)
├── requirements.txt    # Dependências (requests)
└── README.md           # Este arquivo
```

## 🚀 Como Iniciar

A partir de agora **há apenas 1 arquivo público** para iniciar e gerir o sistema: **`IA/launcher.py`**. Todas as versões auxiliares e scripts antigos foram movidos para `IA/archive/`.

### Iniciar o Launcher (recomendado)

Abra um terminal na raiz do projeto e execute:

```bash
python IA/launcher.py
```

Isso inicia o **Launcher (porta 5001)** que fornece:
- Interface web do launcher: http://localhost:5001/
- Endpoints para controlar o servidor IA (`/start`, `/stop`, `/status`)

O próprio launcher inicia o servidor IA (wrapper em `SERVIDOR/server.py`) automaticamente quando necessário.

> Se preferir, os scripts antigos ainda estão disponíveis em `IA/archive/` para referência.

## 🧪 Testar a Conexão

1. Abra o DocHub no navegador (`index.html`)
2. Clique em ⚙️ (Configurações)
3. Vá até a aba **🧪 Testar Conexão**
4. Cole sua API Key do OpenAI (de https://platform.openai.com/api-keys)
5. Clique em **🚀 Testar Automaticamente**

O sistema vai:
- ✅ Validar sua chave OpenAI
- ✅ Testar os modelos disponíveis
- ✅ Salvar configuração automaticamente
- ✅ Você está pronto para usar!

## 💬 Como Usar o Chat

1. Configure a API Key (veja acima)
2. Na aba **💬 Chat**, digite sua pergunta
3. Clique em **Enviar** ou pressione **Enter**
4. O servidor envia para OpenAI
5. Resposta aparece instantaneamente

## 🛠️ Configuração Manual

### 1. Verificar Python

Abra PowerShell e digite:
```bash
python --version
```

Deve mostrar versão 3.7 ou superior.

### 2. Instalar Dependências

Se a pasta `IA` não tiver sido executada:
```bash
cd IA
pip install requests
```

Ou usando o requirements.txt:
```bash
pip install -r requirements.txt
```

### 3. Executar o Servidor

```bash
python ia.py
```

## 📡 Endpoints da API

### GET /health
Verifica se o servidor está online

```bash
curl http://localhost:5000/health
```

Resposta:
```json
{"status": "online"}
```

### POST /validate
Testa se uma API Key é válida

```bash
curl -X POST http://localhost:5000/validate \
  -H "Content-Type: application/json" \
  -d '{
    "api_key": "sk-...",
    "model": "gpt-3.5-turbo"
  }'
```

Resposta:
```json
{"valid": true, "model": "gpt-3.5-turbo"}
```

### POST /chat
Envia uma mensagem ao OpenAI

```bash
curl -X POST http://localhost:5000/chat \
  -H "Content-Type: application/json" \
  -d '{
    "api_key": "sk-...",
    "model": "gpt-3.5-turbo",
    "message": "Olá!",
    "system_prompt": "Você é um assistente útil"
  }'
```

Resposta:
```json
{
  "success": true,
  "response": "Olá! Como posso ajudar?",
  "tokens": {"prompt": 10, "completion": 5, "total": 15}
}
```

## 🔧 Troubleshooting

### "Python não encontrado"
```
❌ Erro: python: comando não encontrado
✅ Solução: Instale Python de https://www.python.org
           Marque "Add Python to PATH" durante instalação
```

### "Porta 5000 já em uso"
```
❌ Erro: Address already in use
✅ Solução 1: Feche o ia.py que está rodando
✅ Solução 2: Mude a porta em ia.py (procure por port=5000)
```

### "ModuleNotFoundError: No module named 'requests'"
```
❌ Erro: ModuleNotFoundError
✅ Solução: pip install requests
```

### "Conexão recusada ao testar API"
```
❌ Erro: Connection refused
✅ Solução 1: Verifique se ia.py está rodando
✅ Solução 2: Verifique se a URL é http://localhost:5000
✅ Solução 3: Verifique firewall/antivírus
```

### "API Key inválida"
```
❌ Erro: Invalid API key
✅ Solução: - A chave deve começar com "sk-"
            - Verifique em https://platform.openai.com/api-keys
            - Certifique-se que não expirou
            - Verifique se sua conta tem créditos
```

## 📊 Dependências

- **Python**: 3.7+
- **requests**: 2.31.0 (para fazer requisições HTTP)

Nenhuma outra dependência pesada! HTTPServer usa biblioteca nativa do Python.

## 🎯 Modelos Suportados

- `gpt-3.5-turbo` - Rápido e barato (recomendado)
- `gpt-4` - Mais poderoso mas mais caro
- `gpt-4-turbo` - Versão turbo do GPT-4

O sistema testa automaticamente qual você tem acesso e usa o primeiro que funciona.

## 💾 Configurações Salvas

Suas configurações são salvas em:
- **Navegador**: localStorage (API Key, modelo escolhido)
- **Não há** cookie ou arquivo de configuração complexo

## 🚀 Dicas de Performance

1. **Deixe ia.py rodando** - Não precisa reiniciar entre mensagens
2. **Use gpt-3.5-turbo** - É o mais rápido
3. **Feche abas desnecessárias** - Economiza memória do navegador
4. **Limite histórico de chat** - Evita muitos tokens

## 📝 Logs

Para ver o que está acontecendo:
1. Deixe a janela do ia.py aberta
2. Veja as mensagens de log enquanto faz requests
3. Para debug mais detalhado, adicione prints em ia.py

## 🔐 Segurança

- ❌ API Key **nunca** é salva no servidor
- ❌ API Key **nunca** é armazenada em arquivo
- ✅ API Key fica apenas na localStorage do navegador
- ✅ Servidor só comunica com OpenAI quando precisa

## 📚 Documentação Completa

Para mais informações, veja:
- `COMECE_AQUI_NOVO.md` - Guia rápido
- `SISTEMA_COMPLETO.md` - Documentação detalhada
- `index.html` - Código da interface

## ✅ Checklist de Setup

- [ ] Python 3.7+ instalado
- [ ] Executado `iniciar.bat` com sucesso
- [ ] Janela preta mostra "Server running on port 5000"
- [ ] DocHub abre sem erros
- [ ] API Key obtida de https://platform.openai.com/api-keys
- [ ] Teste de conexão passa
- [ ] Chat funciona

---

**Versão**: 2.0 (Simplificada)  
**Última Atualização**: 2024  
**Status**: ✅ Pronto para Usar
