@echo off
REM Converte app.py para executável .exe usando PyInstaller

echo.
echo ╔════════════════════════════════════════════════════════════════╗
echo ║           DocHub IA - Gerador de Executável                   ║
echo ╚════════════════════════════════════════════════════════════════╝
echo.

REM Verifica Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Erro: Python não encontrado
    echo    Instale em: https://www.python.org
    pause
    exit /b 1
)

echo ✅ Python encontrado

REM Instala PyInstaller
echo.
echo Instalando PyInstaller...
pip install pyinstaller -q
if %errorlevel% neq 0 (
    echo ❌ Erro ao instalar PyInstaller
    pause
    exit /b 1
)

echo ✅ PyInstaller instalado

REM Cria o executável
echo.
echo Gerando executável...
echo.

pyinstaller ^
    --onefile ^
    --windowed ^
    --name "DocHub IA" ^
    --icon "" ^
    --add-data "index.html:." ^
    --add-data "styles.css:." ^
    --add-data "script.js:." ^
    --add-data "IA:IA" ^
    app.py

echo.
if %errorlevel% equ 0 (
    echo ╔════════════════════════════════════════════════════════════════╗
    echo ║                    ✅ SUCESSO!                                 ║
    echo ╠════════════════════════════════════════════════════════════════╣
    echo ║ Executável criado em:                                         ║
    echo ║   dist\DocHub IA.exe                                          ║
    echo ║                                                               ║
    echo ║ Você pode:                                                   ║
    echo ║   1. Clicar duplo no .exe para abrir                          ║
    echo ║   2. Copiar para outro PC (não precisa Python!)               ║
    echo ║   3. Criar atalho na área de trabalho                        ║
    echo ╚════════════════════════════════════════════════════════════════╝
) else (
    echo ❌ Erro ao gerar executável
)

pause
