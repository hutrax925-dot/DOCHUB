#!/usr/bin/env python3
from http.server import HTTPServer, BaseHTTPRequestHandler
import json


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        print("GET request received!")
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps({'status': 'ok'}).encode())

    def log_message(self, format, *args):
        pass


if __name__ == '__main__':
    print("Starting server on port 5001...")
    server = HTTPServer(('localhost', 5001), Handler)
    print("Server started!")
    try:
        server.serve_forever()
    except Exception as e:
        print(f"Error: {e}")
