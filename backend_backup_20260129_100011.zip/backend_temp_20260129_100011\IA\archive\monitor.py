#!/usr/bin/env python3
"""
Monitor de Servidor - Roda sempre em background
Verifica se ia.py está online a cada 2 segundos
Se não estiver, inicia automaticamente
Sem nenhuma janela visível
"""

import requests
import subprocess
import sys
import time
import os
import threading

class ServidorMonitor:
    def __init__(self):
        self.processo = None
        self.rodando = True
    
    def verificar_servidor(self):
        """Tenta acessar o servidor"""
        try:
            response = requests.get('http://localhost:5000/health', timeout=2)
            return response.status_code == 200
        except:
            return False
    
    def iniciar_servidor(self):
        """Inicia ia.py em background invisível"""
        if self.processo and self.processo.poll() is None:
            # Já está rodando
            return
        
        script_dir = os.path.dirname(os.path.abspath(__file__))
        ia_script = os.path.join(script_dir, 'ia.py')
        
        print("[MONITOR] Iniciando ia.py...")
        
        try:
            if sys.platform == 'win32':
                # Windows - invisível
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE
                
                self.processo = subprocess.Popen(
                    [sys.executable, ia_script],
                    startupinfo=startupinfo,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
            else:
                # Linux/Mac
                self.processo = subprocess.Popen(
                    [sys.executable, ia_script],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    preexec_fn=os.setsid
                )
            
            print(f"[MONITOR] Processo iniciado (PID: {self.processo.pid})")
        except Exception as e:
            print(f"[MONITOR] Erro ao iniciar: {e}")
    
    def rodar(self):
        """Loop principal - monitora o servidor continuamente"""
        print("[MONITOR] ✅ Monitor iniciado")
        print("[MONITOR] Verificando servidor a cada 2 segundos...")
        
        contador = 0
        
        while self.rodando:
            try:
                if not self.verificar_servidor():
                    if contador % 3 == 0:  # Log a cada 6 segundos
                        print(f"[MONITOR] Servidor offline - iniciando...")
                    self.iniciar_servidor()
                else:
                    if contador % 15 == 0:  # Log a cada 30 segundos
                        print(f"[MONITOR] ✅ Servidor online")
                
                contador += 1
                time.sleep(2)
            
            except KeyboardInterrupt:
                print("[MONITOR] Parando...")
                self.rodando = False
            except Exception as e:
                print(f"[MONITOR] Erro: {e}")
                time.sleep(2)
    
    def parar(self):
        """Para o monitor e o servidor"""
        self.rodando = False
        if self.processo:
            try:
                self.processo.terminate()
            except:
                pass

def main():
    """Inicia o monitor"""
    # Instala requests se necessário
    try:
        import requests
    except ImportError:
        print("[MONITOR] Instalando requests...")
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'requests', '-q'])
    
    monitor = ServidorMonitor()
    monitor.rodar()

if __name__ == '__main__':
    main()
