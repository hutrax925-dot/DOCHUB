"""
Teste de integração (opcional) para o launcher.
Execute manualmente: python test_launcher_readiness.py

O teste inicia o `IA/launcher.py` em foreground (logs em `ia_launcher_test.log`), faz POST /start, aguarda readiness (estado 'running') e depois POST /stop.
Use com cuidado (não execute sem supervisão).
"""

import subprocess
import sys
import time
import urllib.request
import urllib.error
import json
import os

PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))
LAUNCHER = os.path.join(PROJECT_ROOT, 'IA', 'launcher.py')
LAUNCHER_LOG = os.path.join(PROJECT_ROOT, 'IA', 'ia_launcher_test.log')

def http_get(url, timeout=2):
    try:
        req = urllib.request.Request(url, method='GET')
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read().decode('utf-8')
    except Exception as e:
        return None

def http_post(url, timeout=2):
    try:
        req = urllib.request.Request(url, method='POST', data=b'')
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read().decode('utf-8')
    except Exception as e:
        return None

proc = subprocess.Popen([sys.executable, LAUNCHER], cwd=PROJECT_ROOT, stdout=open(LAUNCHER_LOG, 'ab'), stderr=subprocess.STDOUT)
print('Launched launcher, pid=', proc.pid)

# wait for ping
for i in range(20):
    if http_get('http://127.0.0.1:5001/ping'):
        print('Launcher responding')
        break
    time.sleep(0.5)
else:
    print('Launcher did not respond in time; aborting test')
    proc.terminate()
    sys.exit(2)

print('Requesting /start')
http_post('http://127.0.0.1:5001/start')

# poll status
for i in range(60):
    txt = http_get('http://127.0.0.1:5001/status')
    if txt:
        try:
            data = json.loads(txt)
            status = data.get('status')
            print('Status:', status)
            if status == 'running':
                print('Server started successfully')
                break
        except Exception:
            pass
    time.sleep(1)
else:
    print('Server did not become running; check logs')

print('Requesting /stop')
http_post('http://127.0.0.1:5001/stop')
for i in range(30):
    txt = http_get('http://127.0.0.1:5001/status')
    if txt:
        try:
            data = json.loads(txt)
            status = data.get('status')
            print('Status after stop:', status)
            if status == 'stopped':
                print('Stopped successfully')
                break
        except Exception:
            pass
    time.sleep(1)

print('Terminating launcher')
proc.terminate()
proc.wait(timeout=5)
print('Done')