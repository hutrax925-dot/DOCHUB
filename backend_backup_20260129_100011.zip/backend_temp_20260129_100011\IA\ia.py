#!/usr/bin/env python3
"""
DocHub IA - Integração Python Simples
Único arquivo que valida API Key e integra com OpenAI
Roda em http://localhost:5000
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import requests
import threading
import urllib.parse
from datetime import datetime
import sys


class IAHandler(BaseHTTPRequestHandler):
    """Handler para requisições HTTP"""

    def log_request(self, method, path, status=None):
        """Log detalhado de requisições"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        status_str = f" → {status}" if status else ""
        print(f"[{timestamp}] {method} {path}{status_str}")

    def do_GET(self):
        """GET - Health check"""
        if self.path == '/health':
            self.log_request('GET', self.path, '200 OK')
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps({'status': 'online'}).encode())
        else:
            self.log_request('GET', self.path, '404 Not Found')
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        """POST - Processa requisições"""
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8')

        try:
            data = json.loads(body)
        except:
            self.log_request('POST', self.path, '400 Invalid JSON')
            self.send_error(400, 'JSON inválido')
            return

        # Validar API Key
        if self.path == '/validate':
            self.log_request('POST', self.path, 'VALIDANDO...')
            self.handle_validate(data)
        # Chat
        elif self.path == '/chat':
            self.log_request('POST', self.path, 'CHAT...')
            self.handle_chat(data)
        else:
            self.log_request('POST', self.path, '404 Not Found')
            self.send_error(404, 'Rota não encontrada')

    def handle_validate(self, data):
        """Valida a API Key usando endpoint /models (mais simples)"""
        api_key = data.get('api_key', '').strip()
        model = data.get('model', 'gpt-3.5-turbo')

        if not api_key:
            print("  ❌ API Key vazia")
            self.send_json(400, {
                'valid': False,
                'error': 'API Key não fornecida'
            })
            return

        if not api_key.startswith('sk-'):
            print("  ❌ Formato de chave inválido")
            self.send_json(400, {
                'valid': False,
                'error': 'Formato de chave inválido'
            })
            return

        print(f"  🔑 Testando chave: {api_key[:10]}...")
        # Testa com OpenAI usando endpoint /models (mais rápido e simples)
        try:
            response = requests.get(
                'https://api.openai.com/v1/models',
                headers={
                    'Authorization': f'Bearer {api_key}',
                    'Content-Type': 'application/json'
                },
                timeout=10
            )

            print(f"  📊 /models response: {response.status_code}")

            if response.status_code == 401:
                print("  ❌ Chave inválida")
                self.send_json(200, {
                    'valid': False,
                    'error': 'Chave de API inválida ou expirada'
                })
            elif response.status_code == 200:
                # Chave é válida! Agora testa se consegue fazer um chat
                print("  ✅ Chave válida! Testando chat...")
                self.test_chat(api_key, model)
            else:
                # Qualquer outro erro (429, 500, etc) = chave funciona, mas tem outro problema
                # Vamos considerar como válida mesmo assim
                print(f"  ⚠️  Status {response.status_code}, tentando chat...")
                self.test_chat(api_key, model)
        except Exception as e:
            print(f"  ⚠️  Erro de conexão: {str(e)}")
            # Se der erro de conexão, tenta fazer o chat mesmo assim
            self.test_chat(api_key, model)

    def test_chat(self, api_key, model):
        """Testa se consegue fazer um chat com a chave"""
        try:
            response = requests.post(
                'https://api.openai.com/v1/chat/completions',
                headers={
                    'Authorization': f'Bearer {api_key}',
                    'Content-Type': 'application/json'
                },
                json={
                    'model': model,
                    'messages': [{'role': 'user', 'content': 'test'}],
                    'max_tokens': 5
                },
                timeout=10
            )

            print(f"  💬 /chat response: {response.status_code}")

            if response.status_code == 200:
                print("  ✅ Chat OK - Chave funcional!")
                self.send_json(200, {
                    'valid': True,
                    'error': None
                })
            elif response.status_code == 401:
                print("  ❌ Chave rejeitada")
                self.send_json(200, {
                    'valid': False,
                    'error': 'Chave inválida'
                })
            else:
                # Outros erros (429, 404 modelo não existe, etc) = considerar válido
                # porque a chave respondeu, só que teve outro problema
                print(
                    f"  ⚠️  Status {response.status_code}, considerando válido")
                self.send_json(200, {
                    'valid': True,
                    'error': None
                })
        except Exception as e:
            print(f"  ⚠️  Erro: {str(e)}")
            # Se der erro, considerar válido mesmo assim (pode ser conexão)
            self.send_json(200, {
                'valid': True,
                'error': None
            })

    def handle_chat(self, data):
        """Processa mensagens de chat"""
        api_key = data.get('api_key', '').strip()
        model = data.get('model', 'gpt-3.5-turbo')
        message = data.get('message', '').strip()
        system_prompt = data.get('system_prompt', 'Você é um assistente útil')
        temperature = data.get('temperature', 0.7)

        if not api_key or not message:
            print("  ❌ API Key ou mensagem vazia")
            self.send_json(400, {
                'success': False,
                'error': 'API Key ou mensagem vazia'
            })
            return

        print(
            f"  💬 Enviando mensagem ({len(message)} chars) com modelo {model}...")
        try:
            response = requests.post(
                'https://api.openai.com/v1/chat/completions',
                headers={
                    'Authorization': f'Bearer {api_key}',
                    'Content-Type': 'application/json'
                },
                json={
                    'model': model,
                    'messages': [
                        {'role': 'system', 'content': system_prompt},
                        {'role': 'user', 'content': message}
                    ],
                    'temperature': temperature,
                    'max_tokens': 2000
                },
                timeout=30
            )

            if response.status_code == 200:
                data_resp = response.json()
                tokens = data_resp['usage']['total_tokens']
                response_text = data_resp['choices'][0]['message']['content']
                print(
                    f"  ✅ Resposta OK ({tokens} tokens, {len(response_text)} chars)")
                self.send_json(200, {
                    'success': True,
                    'response': response_text,
                    'tokens': tokens,
                    'model': model
                })
            else:
                print(f"  ❌ Erro {response.status_code}")
                self.send_json(200, {
                    'success': False,
                    'error': f'Erro {response.status_code}'
                })
        except Exception as e:
            print(f"  ❌ Exceção: {str(e)}")
            self.send_json(200, {
                'success': False,
                'error': str(e)[:100]
            })

    def send_json(self, status_code, data):
        """Envia resposta JSON"""
        self.send_response(status_code)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

    def do_OPTIONS(self):
        """Handle CORS preflight"""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def log_message(self, format, *args):
        """Silencia logs desnecessários"""
        pass


def run_server(port=5000):
    """Inicia o servidor"""
    server = HTTPServer(('localhost', port), IAHandler)
    print("\n" + "="*60)
    print("   🚀 SERVIDOR IA DOCTHUB INICIADO")
    print("="*60)
    print(f"   📍 URL: http://localhost:{port}")
    print(f"   Início: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
    print("="*60)
    print("   Endpoints:")
    print("   • GET  /health   → Status do servidor")
    print("   • POST /validate → Validar API Key")
    print("   • POST /chat     → Enviar mensagem")
    print("="*60)
    print("   🛑 Pressione Ctrl+C para parar")
    print("="*60 + "\n")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n" + "="*60)
        print("   ⛔ SERVIDOR PARADO")
        print("="*60)
        print(f"   Fim: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
        print("="*60 + "\n")
        server.shutdown()


if __name__ == '__main__':
    run_server()
